# STRATEGY_DOC.md
# TF + Grid Pyramid v8.0 — Complete System Documentation
# Tài liệu này đủ để một AI/dev khác tiếp tục làm việc mà không cần context cũ

---

## 1. TỔNG QUAN HỆ THỐNG

### Architecture
```
TradingView Chart (Pine Script v8.0)
    │
    │  Webhook POST /webhook  (JSON)
    ▼
FastAPI Server (main.py) ←── Heartbeat 30s (trailing SL update)
    │
    ▼
GridPyramidStrategy (strategy/grid_pyramid.py)   ← SWAP FILE NÀY KHI ĐỔI ALGO
    │
    ├── RiskManager (risk/risk_manager.py)        ← DD Cap, SL calc
    │
    └── MT5Executor (mt5_executor.py)             ← All MT5 API calls
            │
            ▼
        MetaTrader 5 (Wine on Ubuntu VPS)
            │
            ▼
        Exness Demo → XAUUSD
```

### Tech Stack
- **OS**: Ubuntu 22.04 LTS VPS
- **MT5**: Wine 64-bit + MetaTrader 5 terminal
- **Python**: 3.11+
- **Web**: FastAPI + uvicorn
- **MT5 API**: `MetaTrader5` Python package (chính thức từ MetaQuotes)
- **Notifications**: Telegram Bot API
- **Logs**: structlog → `logs/bot.log` (rotating 10MB × 5)

---

## 2. THUẬT TOÁN: TF + GRID PYRAMID v8.0

### Triết lý
- **Trend Following**: Chỉ vào lệnh khi có breakout cấu trúc (Pivot High/Low break + Impulse candle)
- **Grid Pyramid**: Scale-IN geometric khi giá tiếp tục đúng hướng, Scale-OUT khi đảo chiều
- **Aggressive**: Không filter HTF, không filter session, chấp nhận loss nhỏ thường xuyên để bắt trend lớn
- **Target**: 6-8% profit/tháng, max drawdown < 10%

### State Machine
```
State: 0 = FLAT, 1 = LONG, -1 = SHORT

FLAT  → LONG  : close > pivot_high AND impulse_bar
FLAT  → SHORT : close < pivot_low  AND impulse_bar
LONG  → SHORT : close < pivot_low  AND impulse_bar  (reversal)
LONG  → FLAT  : close < support (structure break)
SHORT → LONG  : close > pivot_high AND impulse_bar  (reversal)
SHORT → FLAT  : close > resistance (structure break)
```

### Entry Logic
```
impulse_bar = (high - low) > ATR(14) * 1.2 AND ATR% >= 0.3%
brkRes      = close > pivot_high AND impulse_bar   (NO open <= resistance check)
brkSup      = close < pivot_low  AND impulse_bar
```
*Không có `open <= resistance` condition — aggressive early entry*

### Grid Pyramid
```
Layer 0 (core): lot = 0.01
Layer 1       : lot = 0.01 × 1.5^1 = 0.015 → round to 0.02
Layer 2       : lot = 0.01 × 1.5^2 = 0.023 → round to 0.02
Layer 3       : lot = 0.01 × 1.5^3 = 0.034 → round to 0.03
Layer 4       : lot = 0.01 × 1.5^4 = 0.051 → round to 0.05

Add  trigger: price moves grid_pips (150 pip) IN FAVOR từ last layer entry
Reduce trigger: price moves grid_pips AGAINST từ last layer entry
Reduce: close 2 youngest layers, NEVER close layer 0
```

### Stop Loss — 2 Phase
```
Phase 1 (trail not active):
    SL = avg_entry - hard_sl_pips (300 pip)  [LONG]
    SL = avg_entry + hard_sl_pips            [SHORT]

Phase 2 (trail active, activate khi lãi >= trail_act_pips = 200 pip):
    trail_sl = peak_price - trail_dist_pips (100 pip)  [LONG]
    trail_sl = trough_price + trail_dist_pips           [SHORT]
    → SL chỉ di chuyển theo chiều có lợi, không bao giờ lùi

Trailing SL update: mỗi 30 giây qua heartbeat loop
Reset trail khi thêm layer mới (avg entry thay đổi)
```

### Risk Gates
```
Max Drawdown Cap: 10% equity
    → Kiểm tra mỗi 30 giây trong heartbeat
    → Nếu floating_loss / equity >= 10% → close_all + notify Telegram
```

---

## 3. CÁC FILE QUAN TRỌNG

### `config.py` — Tất cả parameters
```python
StrategyConfig:
    symbol          = "XAUUSD"
    lot_size        = 0.01         # fixed lot mỗi layer (base)
    pivot_len       = 3            # pivot lookback
    atr_len         = 14
    impulse_mult    = 1.2
    min_atr_pct     = 0.3
    grid_pips       = 150.0        # 150 pip grid step
    geo_mult        = 1.5          # geometric multiplier
    max_layers      = 5
    hard_sl_pips    = 300.0        # 3% of ~$2900 gold price
    trail_act_pips  = 200.0        # activate trailing khi lãi 200 pip
    trail_dist_pips = 100.0        # trail 100 pip dưới peak
    max_dd_pct      = 10.0
```

### `strategy/grid_pyramid.py` — FILE ĐỔI KHI SWAP ALGO
- Class: `GridPyramidStrategy`
- Method chính: `on_signal(signal: SignalEvent)` — webhook gọi vào đây
- Method heartbeat: `update_trailing_sl(current_price)` — heartbeat gọi mỗi 30s
- Method sync: `sync_from_mt5()` — gọi khi restart

### `mt5_executor.py` — MT5 layer
- `open_order(symbol, direction, lot, sl_pips, comment, magic)`
- `close_order(ticket, symbol, lot, direction, magic)`
- `close_all(symbol, magic)`
- `modify_sl(ticket, new_sl, symbol)`
- `get_positions(symbol, magic) → list[PositionInfo]`

### `.env` — Credentials (KHÔNG commit git)
```
MT5_LOGIN=...
MT5_PASSWORD=...
MT5_SERVER=Exness-MT5Trial
MT5_PATH=/root/.wine/drive_c/Program Files/MetaTrader 5/terminal64.exe
TELEGRAM_TOKEN=...
TELEGRAM_CHAT_ID=...
WEBHOOK_SECRET=...
```

---

## 4. SETUP VPS UBUNTU + WINE + MT5

### Bước 1: Install Wine
```bash
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wine64 wine32 winbind xvfb
```

### Bước 2: Cài MT5 trong Wine
```bash
# Download MT5 installer
wget https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe

# Chạy installer (cần virtual display)
Xvfb :0 -screen 0 1024x768x16 &
DISPLAY=:0 wine mt5setup.exe

# MT5 sẽ install vào:
# /root/.wine/drive_c/Program Files/MetaTrader 5/
```

### Bước 3: Chạy MT5 với Xvfb (headless)
```bash
# Start Xvfb
Xvfb :0 -screen 0 1024x768x16 &

# Start MT5 (login lần đầu phải làm thủ công qua VNC)
DISPLAY=:0 wine "/root/.wine/drive_c/Program Files/MetaTrader 5/terminal64.exe" &

# Sau khi đã login xong, MT5 sẽ auto-connect mỗi lần start
```

### Bước 4: Enable MT5 Algo Trading
```
Trong MT5: Tools → Options → Expert Advisors
☑ Allow algorithmic trading
☑ Allow DLL imports
```

### Bước 5: Cài Python + Bot
```bash
sudo apt install -y python3.11 python3.11-pip python3.11-venv

cd /opt
git clone <your-repo> trading-bot
cd trading-bot

python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
nano .env  # điền credentials
```

### Bước 6: Systemd service (auto-restart)
```bash
# Tạo file: /etc/systemd/system/trading-bot.service
```
```ini
[Unit]
Description=TF Grid Pyramid Trading Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trading-bot
Environment="DISPLAY=:0"
ExecStartPre=/bin/bash -c 'Xvfb :0 -screen 0 1024x768x16 &'
ExecStart=/opt/trading-bot/venv/bin/python -m uvicorn main:app --host 0.0.0.0 --port 8000 --workers 1
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable trading-bot
sudo systemctl start trading-bot
sudo systemctl status trading-bot
```

### Bước 7: Firewall
```bash
sudo ufw allow 8000/tcp   # webhook port
sudo ufw allow 22/tcp     # SSH
sudo ufw enable
```

---

## 5. TRADINGVIEW ALERT SETUP

### Pine Script Alert Messages
Trong TradingView, mỗi alertcondition phải được tạo với message JSON:

**LONG_START alert:**
```json
{"secret":"YOUR_WEBHOOK_SECRET","action":"LONG_START","symbol":"XAUUSD","price":{{close}},"atr":{{plot("ATR%")}} }
```

**SHORT_START alert:**
```json
{"secret":"YOUR_WEBHOOK_SECRET","action":"SHORT_START","symbol":"XAUUSD","price":{{close}},"atr":0}
```

**FLAT alert:**
```json
{"secret":"YOUR_WEBHOOK_SECRET","action":"FLAT","symbol":"XAUUSD","price":{{close}},"atr":0}
```

**ADD_LAYER alert:**
```json
{"secret":"YOUR_WEBHOOK_SECRET","action":"ADD_LAYER","symbol":"XAUUSD","price":{{close}},"atr":0}
```

**REDUCE alert:**
```json
{"secret":"YOUR_WEBHOOK_SECRET","action":"REDUCE","symbol":"XAUUSD","price":{{close}},"atr":0}
```

### Alert Settings
```
Webhook URL: http://YOUR_VPS_IP:8000/webhook
Message: (JSON above)
Frequency: Once Per Bar Close  ← QUAN TRỌNG, không dùng Once Per Bar
```

---

## 6. API ENDPOINTS

| Method | Endpoint | Mô tả |
|--------|----------|-------|
| POST | `/webhook` | Nhận tín hiệu từ TradingView |
| GET | `/health` | Health check, MT5 status |
| GET | `/status` | Chi tiết state: layers, avg_entry, PnL |
| POST | `/close-all` | Emergency: đóng tất cả lệnh thủ công |

---

## 7. SWAP THUẬT TOÁN

Khi mày có thuật toán mới:

**Bước 1:** Tạo file mới `strategy/ten_algo_moi.py`

**Bước 2:** Class phải đặt tên theo convention:
```python
# File: strategy/ten_algo_moi.py
class TenAlgoMoiStrategy:
    def __init__(self, cfg: StrategyConfig, executor: MT5Executor): ...
    async def on_signal(self, signal: SignalEvent): ...    # bắt buộc
    async def update_trailing_sl(self, price: float): ... # bắt buộc
    def sync_from_mt5(self): ...                          # bắt buộc
```

**Bước 3:** Sửa `config.py`:
```python
STRATEGY_MODULE = "strategy.ten_algo_moi"
```

**Bước 4:** Restart bot:
```bash
sudo systemctl restart trading-bot
```

---

## 8. MONITORING & TROUBLESHOOTING

### Check logs
```bash
# Live logs
sudo journalctl -u trading-bot -f

# Bot log file
tail -f /opt/trading-bot/logs/bot.log
```

### Test webhook manually
```bash
curl -X POST http://localhost:8000/webhook \
  -H "Content-Type: application/json" \
  -d '{"secret":"YOUR_SECRET","action":"LONG_START","symbol":"XAUUSD","price":2900.5,"atr":0}'
```

### Check status
```bash
curl http://localhost:8000/status | python3 -m json.tool
```

### Common issues

**MT5 not connecting:**
```bash
# Check Wine/MT5 running
ps aux | grep terminal64
# Restart MT5
DISPLAY=:0 wine "/root/.wine/drive_c/Program Files/MetaTrader 5/terminal64.exe" &
```

**Webhook not receiving:**
```bash
# Check port open
sudo netstat -tlnp | grep 8000
# Check firewall
sudo ufw status
```

**Orders not executing:**
- Check MT5: Algo trading enabled?
- Check `magic` number conflict với manual trades?
- Check Exness demo account có đủ margin không?

---

## 9. PARAMETERS TUNING GUIDE

| Param | Tăng | Giảm |
|-------|------|------|
| `pivot_len` | Ít tín hiệu hơn, chắc hơn | Nhiều tín hiệu, nhiều noise |
| `impulse_mult` | Entry chắc hơn, trễ hơn | Entry sớm hơn, nhiều false signal |
| `grid_pips` | Ít add/reduce, theo trend tốt hơn | Add nhiều hơn, overtrade risk |
| `geo_mult` | Pyramid lớn hơn khi trend dài | Risk thấp hơn |
| `hard_sl_pips` | Cho noise nhiều room hơn | Cắt lỗ nhanh hơn |
| `trail_act_pips` | Bảo vệ lãi muộn hơn | Trailing bắt đầu sớm hơn |
| `trail_dist_pips` | SL xa hơn, giữ trend lâu hơn | Bảo vệ lãi nhiều hơn |
| `max_dd_pct` | Cho phép drawdown lớn hơn | Cắt lỗ sớm hơn |

---

## 10. FUTURE IMPROVEMENTS (chưa implement)

- [ ] Partial Take Profit khi R:R đạt 1:2
- [ ] HTF Trend Filter (H1/H4 EMA) — option toggle
- [ ] Session filter (London/NY only)
- [ ] Database logging (SQLite) để track historical trades
- [ ] Web dashboard để monitor real-time
- [ ] Multiple symbol support
- [ ] Backtesting integration với Python (vectorbt/backtrader)
