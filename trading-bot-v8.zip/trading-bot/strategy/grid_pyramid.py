"""
strategy/grid_pyramid.py — TF + Grid Pyramid v8.0 [Aggressive]
=================================================================
ĐÂY LÀ FILE DUY NHẤT CẦN THAY KHI ĐỔI THUẬT TOÁN.

Nhận vào: SignalEvent từ TradingView webhook
Xử lý  : State machine + pyramid layer management
Output : Lệnh vào MT5 qua executor

Triết lý:
  - Entry aggressive: pivot break + impulse, không filter HTF
  - Scale-IN geometric khi giá đi đúng hướng (grid_pips)
  - Scale-OUT khi giá đảo chiều grid_pips (giữ core layer 0)
  - Hard SL từ avg entry → Trailing SL khi đủ lãi
  - DD Cap = risk gate duy nhất
"""

import asyncio
from dataclasses import dataclass, field
from typing import Optional

from config import StrategyConfig
from mt5_executor import MT5Executor, PositionInfo, pips_to_price, price_to_pips
from risk.risk_manager import RiskManager
from utils.logger import log
from utils.notifier import notifier


# ─────────────────────────────────────────────────────────────────────────────
# Signal schema — TradingView webhook sẽ POST JSON theo format này
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SignalEvent:
    """
    Payload từ TradingView alert.
    Xem STRATEGY_DOC.md để biết cách setup alert message.
    """
    action:    str          # "LONG_START" | "SHORT_START" | "FLAT" | "ADD_LAYER" | "REDUCE" | "DD_CAP"
    symbol:    str          # "XAUUSD"
    price:     float        # close price tại thời điểm signal
    atr:       float = 0.0  # optional, dùng để log


# ─────────────────────────────────────────────────────────────────────────────
# Pyramid State — track layer bên ngoài MT5
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PyramidState:
    direction:      str   = ""      # "BUY" | "SELL" | ""
    layers:         int   = 0
    tickets:        list  = field(default_factory=list)   # MT5 ticket mỗi layer
    entry_prices:   list  = field(default_factory=list)   # giá mở mỗi layer
    lot_sizes:      list  = field(default_factory=list)   # lot mỗi layer
    peak_price:     float = 0.0     # high nhất (BUY) hoặc low nhất (SELL) kể từ entry
    trail_active:   bool  = False

    def reset(self):
        self.direction    = ""
        self.layers       = 0
        self.tickets      = []
        self.entry_prices = []
        self.lot_sizes    = []
        self.peak_price   = 0.0
        self.trail_active = False

    @property
    def avg_entry(self) -> float:
        if not self.entry_prices:
            return 0.0
        total_cost = sum(p * l for p, l in zip(self.entry_prices, self.lot_sizes))
        total_lot  = sum(self.lot_sizes)
        return total_cost / total_lot if total_lot > 0 else 0.0

    @property
    def total_lot(self) -> float:
        return sum(self.lot_sizes)

    @property
    def last_entry_price(self) -> float:
        return self.entry_prices[-1] if self.entry_prices else 0.0

    def next_add_price(self, grid_price_dist: float) -> float:
        if not self.entry_prices:
            return 0.0
        lp = self.last_entry_price
        return lp + grid_price_dist if self.direction == "BUY" else lp - grid_price_dist

    def next_reduce_price(self, grid_price_dist: float) -> float:
        if not self.entry_prices:
            return 0.0
        lp = self.last_entry_price
        return lp - grid_price_dist if self.direction == "BUY" else lp + grid_price_dist


# ─────────────────────────────────────────────────────────────────────────────
# Grid Pyramid Strategy
# ─────────────────────────────────────────────────────────────────────────────

class GridPyramidStrategy:
    """
    Main strategy class.
    Stateful: giữ PyramidState trong memory.
    Khi bot restart: sync lại từ MT5 open positions.
    """

    MAGIC = 20080001   # unique magic number cho bot này

    def __init__(self, cfg: StrategyConfig, executor: MT5Executor):
        self.cfg      = cfg
        self.executor = executor
        self.risk     = RiskManager(cfg, executor)
        self.state    = PyramidState()

        # Pre-compute grid distance in price
        self._grid_dist = pips_to_price(cfg.grid_pips, cfg.symbol)

    # ── Main entry point — called by webhook handler ──────────────────────

    async def on_signal(self, signal: SignalEvent) -> None:
        """
        Process incoming signal from TradingView.
        Đây là hàm duy nhất webhook handler gọi vào.
        """
        log.info("strategy.signal_received",
                 action=signal.action, symbol=signal.symbol, price=signal.price)

        # Enforce DD cap trước mọi thứ
        dd_triggered = await self.risk.enforce_dd_cap()
        if dd_triggered:
            self.state.reset()
            return

        action = signal.action.upper()

        if action == "LONG_START":
            await self._handle_core_entry("BUY", signal)

        elif action == "SHORT_START":
            await self._handle_core_entry("SELL", signal)

        elif action == "FLAT":
            await self._handle_flat(signal)

        elif action == "ADD_LAYER":
            await self._handle_add_layer(signal)

        elif action == "REDUCE":
            await self._handle_reduce(signal)

        else:
            log.warning("strategy.unknown_action", action=action)

    # ── Signal handlers ───────────────────────────────────────────────────

    async def _handle_core_entry(self, direction: str, signal: SignalEvent) -> None:
        """Open core position (layer 0)."""

        # Nếu đang có position ngược chiều → close all trước
        if self.state.layers > 0 and self.state.direction != direction:
            log.info("strategy.reversal_close_all", old=self.state.direction, new=direction)
            self.executor.close_all(self.cfg.symbol, self.MAGIC)
            self.state.reset()
            await asyncio.sleep(0.5)  # nhỏ delay trước khi mở mới

        if self.state.layers > 0:
            log.info("strategy.already_in_position", layers=self.state.layers)
            return

        # Risk check
        check = self.risk.can_open_layer(0)
        if not check.allowed:
            log.warning("strategy.risk_block", reason=check.reason)
            return

        lot = self.cfg.lot_size
        sl_pips = self.cfg.hard_sl_pips

        result = self.executor.open_order(
            symbol    = self.cfg.symbol,
            direction = direction,
            lot       = lot,
            sl_pips   = sl_pips,
            comment   = f"GP_L0_{direction[:1]}",
            magic     = self.MAGIC,
        )

        if result.success:
            self.state.direction    = direction
            self.state.layers       = 1
            self.state.tickets      = [result.ticket]
            self.state.entry_prices = [result.price]
            self.state.lot_sizes    = [lot]
            self.state.peak_price   = result.price
            self.state.trail_active = False

            log.info("strategy.core_entry",
                     direction=direction, price=result.price,
                     sl=result.sl, lot=lot)
            await notifier.order_opened(
                direction, self.cfg.symbol, lot,
                result.price, result.sl, layer=1
            )
        else:
            await notifier.system_alert(
                f"Core entry FAILED: {direction} {self.cfg.symbol}\n{result.message}"
            )

    async def _handle_add_layer(self, signal: SignalEvent) -> None:
        """Add next pyramid layer when price moves in favor."""
        if self.state.layers == 0:
            log.warning("strategy.add_layer_no_position")
            return

        check = self.risk.can_open_layer(self.state.layers)
        if not check.allowed:
            log.info("strategy.add_layer_blocked", reason=check.reason)
            return

        # Verify price is at correct grid level
        expected = self.state.next_add_price(self._grid_dist)
        current  = signal.price
        tolerance = self._grid_dist * 0.3  # 30% tolerance

        if self.state.direction == "BUY" and current < expected - tolerance:
            log.debug("strategy.add_price_not_reached",
                      expected=expected, current=current)
            return
        if self.state.direction == "SELL" and current > expected + tolerance:
            log.debug("strategy.add_price_not_reached",
                      expected=expected, current=current)
            return

        # Geometric lot sizing
        idx = self.state.layers
        lot = round(self.cfg.lot_size * (self.cfg.geo_mult ** idx), 2)
        lot = max(lot, 0.01)

        # SL cho lệnh mới = hard SL từ avg entry sau khi add
        new_avg = (self.state.avg_entry * self.state.total_lot + signal.price * lot) \
                  / (self.state.total_lot + lot)
        sl_pips = self.cfg.hard_sl_pips

        result = self.executor.open_order(
            symbol    = self.cfg.symbol,
            direction = self.state.direction,
            lot       = lot,
            sl_pips   = sl_pips,
            comment   = f"GP_L{idx}_{self.state.direction[:1]}",
            magic     = self.MAGIC,
        )

        if result.success:
            self.state.layers       += 1
            self.state.tickets.append(result.ticket)
            self.state.entry_prices.append(result.price)
            self.state.lot_sizes.append(lot)
            # Reset trailing khi thêm layer (avg entry thay đổi)
            self.state.trail_active = False

            log.info("strategy.layer_added",
                     layer=self.state.layers, direction=self.state.direction,
                     price=result.price, lot=lot, avg_entry=self.state.avg_entry)
            await notifier.order_opened(
                self.state.direction, self.cfg.symbol, lot,
                result.price, result.sl, layer=self.state.layers
            )

    async def _handle_reduce(self, signal: SignalEvent) -> None:
        """Close youngest layers when price retraces one grid step."""
        if self.state.layers <= 1:
            log.debug("strategy.reduce_skip", layers=self.state.layers)
            return

        # Close up to 2 youngest layers (never close layer 0 — core)
        to_close = min(2, self.state.layers - 1)
        closed_pnl = 0.0

        for _ in range(to_close):
            if len(self.state.tickets) <= 1:
                break
            ticket    = self.state.tickets[-1]
            direction = self.state.direction
            lot       = self.state.lot_sizes[-1]

            positions = self.executor.get_positions(self.cfg.symbol, self.MAGIC)
            pos = next((p for p in positions if p.ticket == ticket), None)
            if pos is None:
                # Already closed externally
                self.state.tickets.pop()
                self.state.entry_prices.pop()
                self.state.lot_sizes.pop()
                self.state.layers -= 1
                continue

            closed_pnl += pos.profit
            success = self.executor.close_order(
                ticket, self.cfg.symbol, lot, direction, self.MAGIC
            )
            if success:
                self.state.tickets.pop()
                self.state.entry_prices.pop()
                self.state.lot_sizes.pop()
                self.state.layers -= 1
                log.info("strategy.layer_reduced",
                         ticket=ticket, layers_remaining=self.state.layers)

        await notifier.order_closed(
            self.cfg.symbol, self.state.direction,
            "Reduce", closed_pnl
        )

    async def _handle_flat(self, signal: SignalEvent) -> None:
        """Trend ended — close all positions."""
        if self.state.layers == 0:
            return

        pnl = self.executor.get_total_profit(self.cfg.symbol)
        self.executor.close_all(self.cfg.symbol, self.MAGIC)
        self.state.reset()

        log.info("strategy.flat_close_all", pnl=pnl)
        await notifier.order_closed(
            self.cfg.symbol, "ALL", "Trend End", pnl
        )

    # ── Trailing SL management — called every bar by heartbeat ────────────

    async def update_trailing_sl(self, current_price: float) -> None:
        """
        Gọi định kỳ (mỗi bar mới hoặc mỗi phút) để cập nhật trailing SL.
        Không phụ thuộc vào TradingView signal.
        """
        if self.state.layers == 0 or not self.state.direction:
            return

        direction = self.state.direction
        avg       = self.state.avg_entry

        # Update peak price
        if direction == "BUY":
            if current_price > self.state.peak_price:
                self.state.peak_price = current_price
        else:
            if current_price < self.state.peak_price or self.state.peak_price == 0:
                self.state.peak_price = current_price

        # Check trail activation
        was_active = self.state.trail_active
        self.state.trail_active = self.risk.is_trail_activated(
            avg, self.state.peak_price, direction
        )

        if self.state.trail_active:
            new_sl = self.risk.calc_trail_sl(self.state.peak_price, direction)

            # Notify once on activation
            if not was_active:
                log.info("strategy.trail_activated",
                         direction=direction, peak=self.state.peak_price, trail_sl=new_sl)
                await notifier.trail_activated(self.cfg.symbol, direction, new_sl)

            # Update SL on all open positions
            positions = self.executor.get_positions(self.cfg.symbol, self.MAGIC)
            for pos in positions:
                # Only move SL in favorable direction
                should_update = (
                    (direction == "BUY"  and new_sl > pos.current_sl) or
                    (direction == "SELL" and new_sl < pos.current_sl)
                )
                if should_update:
                    self.executor.modify_sl(pos.ticket, new_sl, self.cfg.symbol)

    # ── State sync — rebuild from MT5 on restart ──────────────────────────

    def sync_from_mt5(self) -> None:
        """
        Gọi khi bot restart. Rebuild PyramidState từ open positions trên MT5.
        Đảm bảo bot không bị mù khi khởi động lại.
        """
        positions = self.executor.get_positions(self.cfg.symbol, self.MAGIC)
        if not positions:
            log.info("strategy.sync_no_positions")
            return

        # Sort by open time (ticket order thường là thứ tự mở)
        positions.sort(key=lambda p: p.ticket)

        # Determine direction từ position đầu tiên
        direction = positions[0].direction
        self.state.direction    = direction
        self.state.layers       = len(positions)
        self.state.tickets      = [p.ticket for p in positions]
        self.state.entry_prices = [p.open_price for p in positions]
        self.state.lot_sizes    = [p.lot for p in positions]

        # Peak price: lấy giá hiện tại làm baseline
        bid, ask = self.executor.get_current_price(self.cfg.symbol)
        current  = bid if direction == "BUY" else ask
        self.state.peak_price = current

        # Check if trailing was active
        self.state.trail_active = self.risk.is_trail_activated(
            self.state.avg_entry, self.state.peak_price, direction
        )

        log.info("strategy.synced_from_mt5",
                 direction=direction, layers=self.state.layers,
                 avg_entry=self.state.avg_entry,
                 trail_active=self.state.trail_active)
