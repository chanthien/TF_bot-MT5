"""
mt5_executor.py — MT5 connection layer & order execution
Toàn bộ giao tiếp với MetaTrader 5 nằm ở đây.
Strategy layer không biết gì về MT5 internals.
"""

import asyncio
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Optional

import MetaTrader5 as mt5

from config import MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_PATH, STRATEGY_CFG
from utils.logger import log
from utils.notifier import notifier


# ── Pip → Price conversion for XAU ───────────────────────────────────────
# Exness XAU/USD: 1 pip = 0.1 price (5-digit broker), point = 0.01
# Ta dùng "pip" = 10 points để nhất quán với cách nói thông thường

def pips_to_price(pips: float, symbol: str = "XAUUSD") -> float:
    """Convert pip value to price difference."""
    info = mt5.symbol_info(symbol)
    if info is None:
        return pips * 0.1          # fallback: XAU 1 pip = 0.1
    return pips * info.point * 10  # 1 pip = 10 points


def price_to_pips(price_diff: float, symbol: str = "XAUUSD") -> float:
    info = mt5.symbol_info(symbol)
    if info is None:
        return price_diff / 0.1
    return price_diff / (info.point * 10)


# ── Data classes ──────────────────────────────────────────────────────────

@dataclass
class OrderResult:
    success: bool
    ticket:  int       = 0
    price:   float     = 0.0
    sl:      float     = 0.0
    message: str       = ""


@dataclass
class PositionInfo:
    ticket:      int
    symbol:      str
    direction:   str      # "BUY" | "SELL"
    lot:         float
    open_price:  float
    current_sl:  float
    profit:      float
    comment:     str


# ── MT5 Executor ──────────────────────────────────────────────────────────

class MT5Executor:

    def __init__(self):
        self._connected = False

    # ── Connection ────────────────────────────────────────────────────────

    def connect(self) -> bool:
        """Initialize MT5 connection. Call once at startup."""
        if not mt5.initialize(
            path     = MT5_PATH,
            login    = MT5_LOGIN,
            password = MT5_PASSWORD,
            server   = MT5_SERVER,
        ):
            log.error("mt5.connect_failed", error=mt5.last_error())
            return False

        info = mt5.account_info()
        if info is None:
            log.error("mt5.account_info_failed", error=mt5.last_error())
            return False

        self._connected = True
        log.info("mt5.connected",
                 login=info.login, server=info.server,
                 balance=info.balance, equity=info.equity,
                 currency=info.currency)
        return True

    def disconnect(self) -> None:
        mt5.shutdown()
        self._connected = False
        log.info("mt5.disconnected")

    def is_connected(self) -> bool:
        return self._connected and mt5.terminal_info() is not None

    def reconnect(self) -> bool:
        log.warning("mt5.reconnecting")
        mt5.shutdown()
        time.sleep(2)
        return self.connect()

    # ── Account info ──────────────────────────────────────────────────────

    def get_equity(self) -> float:
        info = mt5.account_info()
        return info.equity if info else 0.0

    def get_balance(self) -> float:
        info = mt5.account_info()
        return info.balance if info else 0.0

    # ── Symbol helpers ────────────────────────────────────────────────────

    def get_current_price(self, symbol: str) -> tuple[float, float]:
        """Returns (bid, ask)"""
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            return 0.0, 0.0
        return tick.bid, tick.ask

    def _normalize_price(self, price: float, symbol: str) -> float:
        info = mt5.symbol_info(symbol)
        if info is None:
            return round(price, 2)
        return round(price, info.digits)

    def _normalize_lot(self, lot: float, symbol: str) -> float:
        info = mt5.symbol_info(symbol)
        if info is None:
            return lot
        step  = info.volume_step
        min_l = info.volume_min
        lot   = max(min_l, round(lot / step) * step)
        return round(lot, 2)

    # ── Order execution ───────────────────────────────────────────────────

    def open_order(
        self,
        symbol:    str,
        direction: str,      # "BUY" | "SELL"
        lot:       float,
        sl_pips:   float,
        comment:   str = "",
        magic:     int = 20080001,
    ) -> OrderResult:
        """
        Open market order với SL tính theo pip.
        TP không đặt — trailing SL sẽ quản lý exit.
        """
        if not self.is_connected():
            if not self.reconnect():
                return OrderResult(success=False, message="MT5 not connected")

        bid, ask = self.get_current_price(symbol)
        if bid == 0:
            return OrderResult(success=False, message="Cannot get price")

        sl_price = pips_to_price(sl_pips, symbol)
        lot      = self._normalize_lot(lot, symbol)

        if direction == "BUY":
            order_type = mt5.ORDER_TYPE_BUY
            price      = ask
            sl         = self._normalize_price(price - sl_price, symbol)
        else:
            order_type = mt5.ORDER_TYPE_SELL
            price      = bid
            sl         = self._normalize_price(price + sl_price, symbol)

        request = {
            "action"   : mt5.TRADE_ACTION_DEAL,
            "symbol"   : symbol,
            "volume"   : lot,
            "type"     : order_type,
            "price"    : price,
            "sl"       : sl,
            "deviation": 20,           # max slippage points
            "magic"    : magic,
            "comment"  : comment[:31], # MT5 max 31 chars
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)

        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            err = result.comment if result else str(mt5.last_error())
            log.error("mt5.order_failed", direction=direction, symbol=symbol,
                      lot=lot, retcode=getattr(result, "retcode", -1), error=err)
            return OrderResult(success=False, message=err)

        log.info("mt5.order_opened", ticket=result.order, direction=direction,
                 symbol=symbol, lot=lot, price=result.price, sl=sl)
        return OrderResult(success=True, ticket=result.order,
                           price=result.price, sl=sl)

    def close_order(self, ticket: int, symbol: str, lot: float,
                    direction: str, magic: int = 20080001) -> bool:
        """Close a specific order by ticket."""
        if not self.is_connected():
            self.reconnect()

        bid, ask = self.get_current_price(symbol)
        close_price = bid if direction == "BUY" else ask
        close_type  = mt5.ORDER_TYPE_SELL if direction == "BUY" else mt5.ORDER_TYPE_BUY

        request = {
            "action"     : mt5.TRADE_ACTION_DEAL,
            "symbol"     : symbol,
            "volume"     : lot,
            "type"       : close_type,
            "position"   : ticket,
            "price"      : close_price,
            "deviation"  : 20,
            "magic"      : magic,
            "comment"    : "bot_close",
            "type_time"  : mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        success = result is not None and result.retcode == mt5.TRADE_RETCODE_DONE
        if success:
            log.info("mt5.order_closed", ticket=ticket, symbol=symbol)
        else:
            log.error("mt5.close_failed", ticket=ticket,
                      retcode=getattr(result, "retcode", -1))
        return success

    def close_all(self, symbol: str, magic: int = 20080001) -> int:
        """Close all open positions for symbol. Returns count closed."""
        positions = self.get_positions(symbol, magic)
        closed = 0
        for pos in positions:
            if self.close_order(pos.ticket, symbol, pos.lot,
                                pos.direction, magic):
                closed += 1
        log.info("mt5.close_all", symbol=symbol, closed=closed)
        return closed

    def modify_sl(self, ticket: int, new_sl: float, symbol: str) -> bool:
        """Modify SL of an open position."""
        if not self.is_connected():
            self.reconnect()

        new_sl = self._normalize_price(new_sl, symbol)
        request = {
            "action"  : mt5.TRADE_ACTION_SLTP,
            "position": ticket,
            "sl"      : new_sl,
        }
        result  = mt5.order_send(request)
        success = result is not None and result.retcode == mt5.TRADE_RETCODE_DONE
        if success:
            log.debug("mt5.sl_modified", ticket=ticket, new_sl=new_sl)
        else:
            log.warning("mt5.sl_modify_failed", ticket=ticket,
                        retcode=getattr(result, "retcode", -1))
        return success

    # ── Position queries ──────────────────────────────────────────────────

    def get_positions(self, symbol: str,
                      magic: int = 20080001) -> list[PositionInfo]:
        """Get all open positions for symbol filtered by magic number."""
        raw = mt5.positions_get(symbol=symbol)
        if raw is None:
            return []
        result = []
        for p in raw:
            if p.magic != magic:
                continue
            result.append(PositionInfo(
                ticket     = p.ticket,
                symbol     = p.symbol,
                direction  = "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL",
                lot        = p.volume,
                open_price = p.price_open,
                current_sl = p.sl,
                profit     = p.profit,
                comment    = p.comment,
            ))
        return result

    def get_total_profit(self, symbol: str, magic: int = 20080001) -> float:
        return sum(p.profit for p in self.get_positions(symbol, magic))

    def count_positions(self, symbol: str, magic: int = 20080001) -> int:
        return len(self.get_positions(symbol, magic))


# Singleton
executor = MT5Executor()
