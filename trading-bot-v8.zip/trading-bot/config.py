"""
config.py — Centralized configuration for TF + Grid Pyramid Trading Bot
All credentials loaded from .env, all strategy params editable here.
"""

import os
from dotenv import load_dotenv
from dataclasses import dataclass, field
from typing import Optional

load_dotenv()


# ─────────────────────────────────────────────
# MT5 CONNECTION
# ─────────────────────────────────────────────
MT5_LOGIN    = int(os.getenv("MT5_LOGIN", "0"))
MT5_PASSWORD = os.getenv("MT5_PASSWORD", "")
MT5_SERVER   = os.getenv("MT5_SERVER", "Exness-MT5Trial")   # Exness demo server name
MT5_PATH     = os.getenv(
    "MT5_PATH",
    "/root/.wine/drive_c/Program Files/MetaTrader 5/terminal64.exe"
)

# ─────────────────────────────────────────────
# TELEGRAM
# ─────────────────────────────────────────────
TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ─────────────────────────────────────────────
# SERVER
# ─────────────────────────────────────────────
WEBHOOK_HOST   = os.getenv("WEBHOOK_HOST", "0.0.0.0")
WEBHOOK_PORT   = int(os.getenv("WEBHOOK_PORT", "8000"))
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "change_me_secret_key")


# ─────────────────────────────────────────────
# STRATEGY PARAMETERS
# Swap strategy file → chỉ cần đổi STRATEGY_MODULE
# ─────────────────────────────────────────────
STRATEGY_MODULE = "strategy.grid_pyramid"   # import path của strategy


@dataclass
class StrategyConfig:
    """
    TF + Grid Pyramid v8.0 — Aggressive
    Tất cả params đều ở đây, không hardcode trong strategy file.
    """

    # ── Symbol ──────────────────────────────
    symbol: str       = "XAUUSD"
    lot_size: float   = 0.01          # fixed lot mỗi layer

    # ── Trend Detection ──────────────────────
    pivot_len: int    = 3             # pivot lookback (nhanh)
    atr_len: int      = 14
    impulse_mult: float = 1.2        # impulse candle filter
    min_atr_pct: float  = 0.3        # anti-chop

    # ── Grid Pyramid ─────────────────────────
    grid_pips: float  = 150.0        # khoảng cách add/reduce (pip)
    geo_mult: float   = 1.5          # geometric multiplier mỗi layer
    max_layers: int   = 5

    # ── Stop Loss ────────────────────────────
    hard_sl_pips: float    = 300.0   # hard SL từ avg entry (pip)
    trail_act_pips: float  = 200.0   # trailing activate khi lãi >= X pip
    trail_dist_pips: float = 100.0   # trailing distance từ peak/trough (pip)

    # ── Risk Management ──────────────────────
    max_dd_pct: float = 10.0         # max drawdown % equity → close all


# Singleton instance dùng trong toàn app
STRATEGY_CFG = StrategyConfig()
