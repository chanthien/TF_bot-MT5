"""
risk/risk_manager.py — Risk gate layer
Chạy độc lập với strategy logic.
Đây là lớp bảo vệ cuối cùng trước khi lệnh được gửi vào MT5.
"""

from dataclasses import dataclass
from typing import Optional

from config import StrategyConfig
from mt5_executor import MT5Executor, pips_to_price
from utils.logger import log
from utils.notifier import notifier


@dataclass
class RiskCheckResult:
    allowed:  bool
    reason:   str = ""


class RiskManager:

    def __init__(self, cfg: StrategyConfig, executor: MT5Executor):
        self.cfg      = cfg
        self.executor = executor

    # ── Pre-trade check ───────────────────────────────────────────────────

    def can_open_layer(self, current_layers: int) -> RiskCheckResult:
        """Check if adding a new layer is allowed."""

        # Max layers
        if current_layers >= self.cfg.max_layers:
            return RiskCheckResult(False, f"max layers {self.cfg.max_layers} reached")

        # Drawdown check
        dd_result = self._check_drawdown()
        if not dd_result.allowed:
            return dd_result

        return RiskCheckResult(True)

    # ── Drawdown gate ─────────────────────────────────────────────────────

    def _check_drawdown(self) -> RiskCheckResult:
        equity       = self.executor.get_equity()
        if equity <= 0:
            return RiskCheckResult(False, "equity unavailable")

        open_pnl     = self.executor.get_total_profit(self.cfg.symbol)
        if open_pnl >= 0:
            return RiskCheckResult(True)

        dd_pct = abs(open_pnl) / equity * 100.0
        if dd_pct >= self.cfg.max_dd_pct:
            log.warning("risk.dd_cap_breached", dd_pct=dd_pct,
                        limit=self.cfg.max_dd_pct, equity=equity)
            return RiskCheckResult(
                False,
                f"DD cap: {dd_pct:.2f}% >= {self.cfg.max_dd_pct}%"
            )
        return RiskCheckResult(True)

    async def enforce_dd_cap(self) -> bool:
        """
        Called every bar/tick. If DD cap breached → close all and notify.
        Returns True if cap was triggered.
        """
        equity   = self.executor.get_equity()
        open_pnl = self.executor.get_total_profit(self.cfg.symbol)

        if open_pnl >= 0 or equity <= 0:
            return False

        dd_pct = abs(open_pnl) / equity * 100.0
        if dd_pct >= self.cfg.max_dd_pct:
            log.warning("risk.enforcing_dd_cap", dd_pct=dd_pct, equity=equity)
            closed = self.executor.close_all(self.cfg.symbol)
            await notifier.dd_cap_hit(self.cfg.symbol, dd_pct, equity)
            log.info("risk.dd_cap_enforced", positions_closed=closed)
            return True
        return False

    # ── SL price calculation ──────────────────────────────────────────────

    def calc_hard_sl(self, entry_price: float, direction: str) -> float:
        """Hard SL price from entry price."""
        sl_dist = pips_to_price(self.cfg.hard_sl_pips, self.cfg.symbol)
        if direction == "BUY":
            return entry_price - sl_dist
        return entry_price + sl_dist

    def calc_trail_sl(self, peak_price: float, direction: str) -> float:
        """Trailing SL price from peak/trough."""
        dist = pips_to_price(self.cfg.trail_dist_pips, self.cfg.symbol)
        if direction == "BUY":
            return peak_price - dist
        return peak_price + dist

    def is_trail_activated(self, avg_entry: float,
                            peak_price: float, direction: str) -> bool:
        """Check if trailing SL should activate."""
        act_dist = pips_to_price(self.cfg.trail_act_pips, self.cfg.symbol)
        if direction == "BUY":
            return (peak_price - avg_entry) >= act_dist
        return (avg_entry - peak_price) >= act_dist
