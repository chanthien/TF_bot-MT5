"""
main.py — FastAPI webhook server
Nhận tín hiệu từ TradingView, dispatch sang strategy.
Chạy: uvicorn main:app --host 0.0.0.0 --port 8000
"""

import asyncio
import importlib
import secrets
from contextlib import asynccontextmanager
from datetime import datetime, time as dtime
from typing import Optional

from fastapi import FastAPI, HTTPException, Request, Header, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, validator
import uvicorn

from config import (
    WEBHOOK_HOST, WEBHOOK_PORT, WEBHOOK_SECRET,
    STRATEGY_CFG, STRATEGY_MODULE,
)
from mt5_executor import executor
from utils.logger import log
from utils.notifier import notifier


# ─────────────────────────────────────────────────────────────────────────────
# Strategy loader — hot-swappable
# ─────────────────────────────────────────────────────────────────────────────

def load_strategy():
    """
    Load strategy class theo STRATEGY_MODULE trong config.py.
    Đổi thuật toán: chỉ cần thay STRATEGY_MODULE → restart bot.
    """
    module = importlib.import_module(STRATEGY_MODULE)
    # Convention: strategy class phải là class đầu tiên inherit từ base
    # Tên class lấy từ module name: grid_pyramid → GridPyramidStrategy
    class_name = "".join(w.capitalize() for w in STRATEGY_MODULE.split(".")[-1].split("_")) + "Strategy"
    cls = getattr(module, class_name)
    return cls(STRATEGY_CFG, executor)


# ─────────────────────────────────────────────────────────────────────────────
# Webhook payload schema
# ─────────────────────────────────────────────────────────────────────────────

class WebhookPayload(BaseModel):
    """
    TradingView alert message phải gửi JSON theo format này.
    Xem STRATEGY_DOC.md phần "TradingView Alert Setup".
    """
    secret:  str
    action:  str    # LONG_START | SHORT_START | FLAT | ADD_LAYER | REDUCE
    symbol:  str    = "XAUUSD"
    price:   float  = 0.0
    atr:     float  = 0.0

    @validator("action")
    def validate_action(cls, v):
        valid = {"LONG_START", "SHORT_START", "FLAT", "ADD_LAYER", "REDUCE"}
        if v.upper() not in valid:
            raise ValueError(f"Unknown action: {v}. Valid: {valid}")
        return v.upper()

    @validator("symbol")
    def validate_symbol(cls, v):
        return v.upper()


# ─────────────────────────────────────────────────────────────────────────────
# App lifecycle
# ─────────────────────────────────────────────────────────────────────────────

strategy = None
heartbeat_task = None
daily_summary_task = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global strategy, heartbeat_task, daily_summary_task

    log.info("bot.starting")

    # Connect MT5
    if not executor.connect():
        log.error("bot.mt5_connect_failed")
        await notifier.system_alert("❌ Bot FAILED to connect to MT5 on startup!")
        raise RuntimeError("MT5 connection failed")

    # Load strategy
    strategy = load_strategy()
    log.info("bot.strategy_loaded", module=STRATEGY_MODULE)

    # Sync state từ MT5 (nếu bot restart với positions đang mở)
    strategy.sync_from_mt5()

    # Start heartbeat (trailing SL update mỗi 30s)
    heartbeat_task = asyncio.create_task(_heartbeat_loop())

    # Start daily summary task
    daily_summary_task = asyncio.create_task(_daily_summary_loop())

    await notifier.system_alert(
        f"✅ Bot STARTED\n"
        f"Strategy: {STRATEGY_MODULE}\n"
        f"Symbol: {STRATEGY_CFG.symbol}\n"
        f"Lot: {STRATEGY_CFG.lot_size}"
    )

    log.info("bot.ready")
    yield

    # Shutdown
    if heartbeat_task:
        heartbeat_task.cancel()
    if daily_summary_task:
        daily_summary_task.cancel()
    executor.disconnect()
    await notifier.system_alert("🔴 Bot STOPPED")
    log.info("bot.stopped")


# ─────────────────────────────────────────────────────────────────────────────
# Background tasks
# ─────────────────────────────────────────────────────────────────────────────

async def _heartbeat_loop():
    """
    Chạy mỗi 30 giây:
    - Cập nhật trailing SL
    - Enforce DD cap
    - Check MT5 connection
    """
    while True:
        try:
            await asyncio.sleep(30)

            # Connection health check
            if not executor.is_connected():
                log.warning("heartbeat.mt5_disconnected")
                executor.reconnect()

            if strategy is None:
                continue

            # Get current price
            bid, ask = executor.get_current_price(STRATEGY_CFG.symbol)
            current  = bid if strategy.state.direction == "BUY" else ask

            if current > 0:
                # Update trailing SL
                await strategy.update_trailing_sl(current)

                # Enforce DD cap
                dd_triggered = await strategy.risk.enforce_dd_cap()
                if dd_triggered:
                    strategy.state.reset()

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error("heartbeat.error", error=str(e))
            await notifier.system_alert(f"⚠️ Heartbeat error: {e}")


async def _daily_summary_loop():
    """Push daily summary lúc 00:01 UTC mỗi ngày."""
    while True:
        try:
            now = datetime.utcnow()
            # Tính giây đến 00:01 UTC ngày mai
            next_midnight = datetime(now.year, now.month, now.day, 0, 1, 0)
            if now.hour == 0 and now.minute == 0:
                next_midnight = next_midnight.replace(day=now.day)
            from datetime import timedelta
            if next_midnight <= now:
                next_midnight += timedelta(days=1)
            wait_secs = (next_midnight - now).total_seconds()
            await asyncio.sleep(wait_secs)

            equity  = executor.get_equity()
            balance = executor.get_balance()
            net_pnl = equity - balance
            await notifier.daily_summary(equity, net_pnl, 0, 0)

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error("daily_summary.error", error=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI app
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title    = "TF Grid Pyramid Trading Bot",
    version  = "8.0.0",
    lifespan = lifespan,
)


# ── Security: validate webhook secret ────────────────────────────────────────

def verify_secret(payload: WebhookPayload) -> WebhookPayload:
    if not secrets.compare_digest(payload.secret, WEBHOOK_SECRET):
        log.warning("webhook.invalid_secret")
        raise HTTPException(status_code=403, detail="Invalid secret")
    return payload


# ── Routes ────────────────────────────────────────────────────────────────────

@app.post("/webhook")
async def webhook(payload: WebhookPayload = Depends(verify_secret)):
    """
    Main webhook endpoint. TradingView gửi POST request vào đây.
    URL: http://YOUR_VPS_IP:8000/webhook
    """
    if strategy is None:
        raise HTTPException(status_code=503, detail="Strategy not initialized")

    from strategy.grid_pyramid import SignalEvent
    signal = SignalEvent(
        action = payload.action,
        symbol = payload.symbol,
        price  = payload.price,
        atr    = payload.atr,
    )

    # Process async — không block webhook response
    asyncio.create_task(strategy.on_signal(signal))

    log.info("webhook.received", action=payload.action,
             symbol=payload.symbol, price=payload.price)
    return JSONResponse({"status": "ok", "action": payload.action})


@app.get("/health")
async def health():
    """Health check endpoint."""
    connected = executor.is_connected()
    equity    = executor.get_equity() if connected else 0
    layers    = strategy.state.layers if strategy else 0
    direction = strategy.state.direction if strategy else ""

    return {
        "status"   : "ok" if connected else "degraded",
        "mt5"      : connected,
        "equity"   : equity,
        "symbol"   : STRATEGY_CFG.symbol,
        "layers"   : layers,
        "direction": direction,
        "strategy" : STRATEGY_MODULE,
    }


@app.post("/close-all")
async def close_all_manual():
    """Emergency: close all positions manually."""
    if strategy is None:
        raise HTTPException(status_code=503, detail="Strategy not ready")

    pnl    = executor.get_total_profit(STRATEGY_CFG.symbol)
    closed = executor.close_all(STRATEGY_CFG.symbol)
    strategy.state.reset()

    log.info("manual.close_all", closed=closed, pnl=pnl)
    await notifier.order_closed(STRATEGY_CFG.symbol, "ALL", "Manual Close", pnl)
    return {"closed": closed, "pnl": pnl}


@app.get("/status")
async def status():
    """Detailed bot status."""
    if strategy is None:
        return {"error": "strategy not loaded"}

    s = strategy.state
    return {
        "direction"   : s.direction,
        "layers"      : s.layers,
        "avg_entry"   : round(s.avg_entry, 2),
        "total_lot"   : s.total_lot,
        "peak_price"  : s.peak_price,
        "trail_active": s.trail_active,
        "equity"      : executor.get_equity(),
        "open_pnl"    : executor.get_total_profit(STRATEGY_CFG.symbol),
        "tickets"     : s.tickets,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host    = WEBHOOK_HOST,
        port    = WEBHOOK_PORT,
        reload  = False,
        workers = 1,          # PHẢI là 1 — strategy state là in-memory
    )
