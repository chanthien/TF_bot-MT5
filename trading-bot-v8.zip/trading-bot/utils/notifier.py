"""
utils/notifier.py — Telegram notification service
Async, non-blocking. Nếu Telegram down thì chỉ log warning, không crash bot.
"""

import asyncio
from typing import Optional

import httpx

from config import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
from utils.logger import log


class TelegramNotifier:
    BASE_URL = "https://api.telegram.org/bot{token}/sendMessage"

    def __init__(self, token: str = TELEGRAM_TOKEN, chat_id: str = TELEGRAM_CHAT_ID):
        self.token   = token
        self.chat_id = chat_id
        self.enabled = bool(token and chat_id)
        if not self.enabled:
            log.warning("telegram.disabled", reason="token or chat_id missing")

    async def send(self, text: str, parse_mode: str = "HTML") -> bool:
        """Send message. Returns True on success."""
        if not self.enabled:
            return False
        url = self.BASE_URL.format(token=self.token)
        payload = {
            "chat_id"   : self.chat_id,
            "text"      : text,
            "parse_mode": parse_mode,
        }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                return True
        except Exception as e:
            log.warning("telegram.send_failed", error=str(e))
            return False

    # ── Convenience wrappers ──────────────────────────────────────────────

    async def order_opened(self, direction: str, symbol: str, lot: float,
                           price: float, sl: float, layer: int) -> None:
        emoji = "🟢" if direction == "BUY" else "🔴"
        text  = (
            f"{emoji} <b>ORDER OPENED</b>\n"
            f"Symbol : <code>{symbol}</code>\n"
            f"Direction : <b>{direction}</b> | Layer <b>{layer}</b>\n"
            f"Lot    : {lot}\n"
            f"Price  : {price:.2f}\n"
            f"SL     : {sl:.2f}"
        )
        await self.send(text)

    async def order_closed(self, symbol: str, direction: str,
                           reason: str, pnl: float) -> None:
        emoji = "✅" if pnl >= 0 else "❌"
        text  = (
            f"{emoji} <b>ORDER CLOSED</b>\n"
            f"Symbol : <code>{symbol}</code>\n"
            f"Direction : {direction}\n"
            f"Reason : {reason}\n"
            f"P&L    : <b>{'%.2f' % pnl} USD</b>"
        )
        await self.send(text)

    async def dd_cap_hit(self, symbol: str, dd_pct: float, equity: float) -> None:
        text = (
            f"🚨 <b>DD CAP TRIGGERED</b>\n"
            f"Symbol : <code>{symbol}</code>\n"
            f"DD     : <b>{dd_pct:.2f}%</b>\n"
            f"Equity : {equity:.2f} USD\n"
            f"→ All positions closed."
        )
        await self.send(text)

    async def trail_activated(self, symbol: str, direction: str,
                               trail_sl: float) -> None:
        text = (
            f"🎯 <b>TRAILING SL ACTIVE</b>\n"
            f"Symbol : <code>{symbol}</code>\n"
            f"Direction : {direction}\n"
            f"Trail SL : {trail_sl:.2f}"
        )
        await self.send(text)

    async def system_alert(self, message: str) -> None:
        text = f"⚠️ <b>SYSTEM ALERT</b>\n{message}"
        await self.send(text)

    async def daily_summary(self, equity: float, net_pnl: float,
                             trades: int, win: int) -> None:
        wr   = (win / trades * 100) if trades else 0
        emoji = "📈" if net_pnl >= 0 else "📉"
        text  = (
            f"{emoji} <b>DAILY SUMMARY</b>\n"
            f"Equity    : {equity:.2f} USD\n"
            f"Net P&L   : <b>{'%.2f' % net_pnl} USD</b>\n"
            f"Trades    : {trades} | Win {win} ({wr:.1f}%)"
        )
        await self.send(text)


# Singleton
notifier = TelegramNotifier()
